import { Controller } from '@nestjs/common';

@Controller('review')
export class ReviewController {}
