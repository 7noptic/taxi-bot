export const ALREADY_REGISTERED_ERROR = 'Пользователь с таким email уже зарегистрирован';
export const WRONG_PASSWORD_ERROR = 'Пользователь с таким email уже зарегистрирован';
