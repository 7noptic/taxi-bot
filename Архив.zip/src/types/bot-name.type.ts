export enum BotName {
	Taxi = 'taxi',
	Help = 'help',
}
