export interface OrdersInfoDto {
	totalCount: number;
	driveCount: number;
	deliveryCount: number;
	canceledCount: number;
}
