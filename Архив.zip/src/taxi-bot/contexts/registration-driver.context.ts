export interface RegistrationDriverContext {
	wizard: {
		state: {
			name: string;
			city: string;
			phone: string;
			carBrand: string;
			carColor: string;
			carNumber: string;
		};
	};
}
