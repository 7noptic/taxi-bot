export const registrationButtons = {
	passenger: {
		label: 'Я пассажир 🚶',
		callback: 'register-passenger',
	},
	driver: {
		label: 'Я водитель 🚕',
		callback: 'register-driver',
	},
};
