export const APPEAL_NOT_FOUND = 'Обращение не найдено';
