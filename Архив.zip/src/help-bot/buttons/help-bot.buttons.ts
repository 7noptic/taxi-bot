export const HelpBotButtons = {
	open: {
		label: '📖 Открыть обращение',
		callback: '📖 Открыть обращение',
	},
	close: {
		label: '✅ Проблема решена',
		callback: '✅ Проблема решена',
	},
};
