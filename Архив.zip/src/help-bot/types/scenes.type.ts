export enum ScenesAppealType {
	OpenAppeal = 'open-appeal',
}
