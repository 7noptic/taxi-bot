export interface RegistrationPassengerContext {
	wizard: {
		state: {
			name: string;
			city: string;
			phone: string;
		};
	};
}
