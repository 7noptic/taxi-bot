export interface DeleteAddressContext {
	wizard: {
		state: {
			name: string;
		};
	};
}
