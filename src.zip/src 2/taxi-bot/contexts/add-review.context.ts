export interface AddReviewContext {
	wizard: {
		state: {
			to: number;
			numberOrder: string;
		};
	};
}
