export interface AddAddressContext {
	wizard: {
		state: {
			name: string;
			address: string;
		};
	};
}
