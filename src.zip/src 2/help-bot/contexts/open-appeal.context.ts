export interface OpenAppealContext {
	wizard: {
		state: {
			numberOrder: string;
			message: string;
		};
	};
}
