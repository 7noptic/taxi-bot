export enum LoggerType {
	Error = 'error',
	Warn = 'warn',
	Debug = 'debug',
	Log = 'log',
}
