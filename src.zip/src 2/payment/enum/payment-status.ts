export enum PaymentStatus {
	Paid = 'paid',
	NotPaid = 'notPaid',
}
