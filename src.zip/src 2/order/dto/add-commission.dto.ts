export interface AddCommissionDto {
	commission: number;
	countDays: number;
}
