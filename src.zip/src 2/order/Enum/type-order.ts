export enum TypeOrder {
	DELIVERY = 'delivery',
	DRIVE = 'drive',
}
