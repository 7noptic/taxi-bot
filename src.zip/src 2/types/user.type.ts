export enum UserType {
	Passenger = 'passenger',
	Driver = 'driver',
}
