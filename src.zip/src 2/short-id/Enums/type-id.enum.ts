export enum TypeId {
	Order = 'Заказ',
	Appeal = 'Обращение',
	Payment = 'Оплата',
}
