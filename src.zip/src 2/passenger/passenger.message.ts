export const PASSENGER_NOT_FOUND = 'Пассажир не найден';
